function myMap() {
    var mapOptions = {
        center: new google.maps.LatLng(51.5, -0.12)
        , zoom: 10
        , mapTypeId: google.maps.MapTypeId.HYBRID
    }
    var map = new google.maps.Map(document.getElementById("map"), mapOptions);
} 
    < script src = "https://www.google.ca/maps/@45.4090804,-75.6890276,16.79z"></script>